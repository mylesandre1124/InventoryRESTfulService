CREATE PROCEDURE getEmpId(IN token VARCHAR(250))
  BEGIN

SELECT empId
FROM employee.authorize
where authorizationToken = token
limit 1;

END;
